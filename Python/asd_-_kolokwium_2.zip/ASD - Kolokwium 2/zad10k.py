from zad10ktesty import runtests

def dywany ( N ):
    #Tutaj proszę wpisać własną implementację
    return []


runtests( dywany )

