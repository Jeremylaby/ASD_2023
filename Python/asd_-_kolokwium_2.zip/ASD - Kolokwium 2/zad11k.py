from zad11ktesty import runtests

def kontenerowiec(T):
    #Tutaj proszę wpisać własną implementację

    return 0

runtests ( kontenerowiec )
    