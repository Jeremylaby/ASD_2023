from zad12ktesty import runtests 

def autostrada( T, k ):
    #Tutaj proszę wpisać własną implementację
    return 0 

runtests ( autostrada,all_tests=False )