from zad1ktesty import runtests

def roznica( S ):
    #Tutaj proszę wpisać własną implementację
    return 0

runtests ( roznica )