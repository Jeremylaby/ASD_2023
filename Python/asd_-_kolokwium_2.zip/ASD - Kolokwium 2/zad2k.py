from zad2ktesty import runtests

def palindrom( S ):
    #Tutaj proszę wpisać własną implementację
    return ""

runtests ( palindrom )