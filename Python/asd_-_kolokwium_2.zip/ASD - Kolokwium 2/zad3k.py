from zad3ktesty import runtests

def ksuma( T, k ):
    #Tutaj proszę wpisać własną implementację
    return 0
    
runtests ( ksuma )