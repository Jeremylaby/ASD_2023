from zad4ktesty import runtests

def falisz ( T ):
    #Tutaj proszę wpisać własną implementację
    return 0

runtests ( falisz )
