from zad5ktesty import runtests

def garek ( A ):
    #Tutaj proszę wpisać własną implementację
    return 0

runtests ( garek )