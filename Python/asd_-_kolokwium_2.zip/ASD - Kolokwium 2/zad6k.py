from zad6ktesty import runtests 

def haslo ( S ):
    return -1

runtests ( haslo )