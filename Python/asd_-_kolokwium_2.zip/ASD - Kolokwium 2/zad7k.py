from zad7ktesty import runtests 

def ogrodnik (T, D, Z, l):
    return 0

runtests( ogrodnik, all_tests=False )
