from zad8ktesty import runtests 

def napraw ( s, t ):
    return 0 

runtests ( napraw )