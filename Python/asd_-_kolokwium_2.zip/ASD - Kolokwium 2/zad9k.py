from zad9ktesty import runtests
from math import inf

def prom(P, g, d):
    return []

runtests ( prom )